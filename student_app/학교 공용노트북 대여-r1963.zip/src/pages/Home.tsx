import { useRef, useState } from "react";
import { ArrowRight, BookOpen, Check, CheckCheck, ChevronRight, CircleHelp, GraduationCap, Laptop, LockKeyhole, LogOut, Monitor, ShieldCheck, X } from "lucide-react";
import "../school.css";

function GoogleMark() {
  return <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M21.6 12.23c0-.71-.06-1.39-.18-2.05H12v3.88h5.38a4.6 4.6 0 0 1-2 3.02v2.51h3.24c1.9-1.75 2.98-4.33 2.98-7.36Z"/><path fill="#34A853" d="M12 22c2.7 0 4.96-.9 6.62-2.41l-3.24-2.51c-.9.6-2.05.96-3.38.96-2.6 0-4.81-1.76-5.6-4.12H3.06v2.59A10 10 0 0 0 12 22Z"/><path fill="#FBBC05" d="M6.4 13.92a6 6 0 0 1 0-3.84V7.49H3.06a10 10 0 0 0 0 9.02l3.34-2.59Z"/><path fill="#EA4335" d="M12 5.96c1.47 0 2.79.5 3.83 1.5l2.88-2.88A9.62 9.62 0 0 0 12 2a10 10 0 0 0-8.94 5.49l3.34 2.59c.79-2.36 3-4.12 5.6-4.12Z"/></svg>;
}

function LaptopArt() {
  return <div className="laptop-art" aria-hidden="true">
    <div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/>
    <span className="art-spark spark-one">+</span><span className="art-spark spark-two">+</span><span className="art-dot"/>
    <div className="floating-book"><BookOpen size={23}/></div>
    <svg className="laptop-drawing" viewBox="0 0 480 280" fill="none">
      <ellipse cx="240" cy="250" rx="180" ry="14" fill="#dce5f5" opacity=".55"/>
      <path d="M100 48a12 12 0 0 1 12-12h256a12 12 0 0 1 12 12v176H100V48Z" fill="#2a3d61"/>
      <path d="M109 50a5 5 0 0 1 5-5h252a5 5 0 0 1 5 5v164H109V50Z" fill="#EDF3FF"/>
      <circle cx="240" cy="40.5" r="2" fill="#8e9db8"/>
      <path d="M110 214h260v10H110z" fill="#182b4c"/>
      <path d="m100 224-43 19c-5 3-3 9 3 9h360c6 0 8-6 3-9l-43-19H100Z" fill="#becde6"/>
      <path d="M57 246h366c-1 4-5 6-10 6H67c-5 0-9-2-10-6Z" fill="#92a8c8"/>
      <path d="m212 224-6 9h68l-6-9h-56Z" fill="#92a8c8"/>
      <rect x="128" y="62" width="224" height="132" rx="7" fill="white"/>
      <rect x="128" y="62" width="224" height="21" rx="7" fill="#F5F7FC"/>
      <circle cx="139" cy="72" r="2.5" fill="#d2dded"/><circle cx="148" cy="72" r="2.5" fill="#d2dded"/><circle cx="157" cy="72" r="2.5" fill="#d2dded"/>
      <rect x="215" y="96" width="50" height="48" rx="14" fill="#edf3ff"/>
      <path d="M240 104 255 110v10c0 9-15 17-15 17s-15-8-15-17v-10l15-6Z" fill="#3064df"/>
      <path d="m233 119 5 5 9-10" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
      <rect x="207" y="155" width="66" height="5" rx="2.5" fill="#324c75"/><rect x="190" y="168" width="100" height="4" rx="2" fill="#e0e7f3"/>
    </svg>
    <div className="art-safe"><span><ShieldCheck size={20}/></span><div><strong>안전하게 연결된 배움</strong><small>학교 계정으로 함께해요</small></div><span className="safe-dot"/></div>
  </div>;
}

export default function Home() {
  const [email, setEmail] = useState("");
  const [dialog, setDialog] = useState<"login" | "help" | "rules" | null>(null);
  const [demo, setDemo] = useState(false);
  const dialogRef = useRef<HTMLDialogElement>(null);
  function openDialog(kind: "login" | "help" | "rules") { setDialog(kind); dialogRef.current?.showModal(); }
  function closeDialog() { dialogRef.current?.close(); setDialog(null); }
  return (
    <main className="school-app">
      <a className="school-skip" href="#school-email">로그인 입력으로 건너뛰기</a>
      <header className="school-header">
        <a href="/" className="school-brand" aria-label="스쿨패스 홈"><span className="brand-symbol"><GraduationCap size={25} strokeWidth={1.8}/></span><span className="brand-name">스쿨패스<span>학교 공용 노트북</span></span></a>
        <div className="header-right"><span className="connection"><i/> 이용 준비 완료</span><span className="header-divider"/><button className="help-button" onClick={() => openDialog("help")}><CircleHelp size={17}/> 도움이 필요해요</button></div>
      </header>

      <section className="school-main" aria-label="노트북 이용 시작">
        <div className="welcome-side">
          <div className="welcome-badge"><span/> 우리의 배움이 시작되는 곳</div>
          <h1>반가워요!<br/>오늘도 함께 배워요.</h1>
          <p className="welcome-copy">학교 구글 계정으로 로그인하고,<br/>나의 배움을 위한 노트북을 시작해 보세요.</p>
          <LaptopArt/>
          <div className="welcome-caption"><ShieldCheck size={16}/><span>학생 확인부터 안전한 이용까지, 스쿨패스와 함께해요.</span></div>
        </div>

        <div className="signin-side">
          <div className="login-card">
            <div className="card-topline"><span className="lock-symbol">{demo ? <CheckCheck size={23}/> : <LockKeyhole size={23}/>}</span><span className={demo ? "state-pill demo-pill" : "state-pill"}><span/>{demo ? "이용 화면 예시" : "로그인 대기 중"}</span></div>
            {demo ? <>
              <h2>사용할 준비가 됐어요.</h2><p className="card-description">로그인 후 표시되는 화면 예시예요.</p>
              <div className="demo-account"><span className="account-icon"><GraduationCap size={26}/></span><strong>{email}</strong><small>실제 계정 확인이나 기기 잠금 해제는 하지 않았어요.</small></div>
              <div className="ready-notice"><Monitor size={20}/><div><b>노트북 이용 화면</b><p>학교 계정 연결 후 실제 이용을 시작할 수 있어요.</p></div></div>
              <button className="primary-button" onClick={() => {setDemo(false); setEmail("");}}><LogOut size={18}/> 로그인 화면으로 돌아가기</button>
            </> : <>
              <h2>학교 계정으로 로그인</h2><p className="card-description">노트북을 이용하기 전에 학생 확인이 필요해요.</p>
              <form className="login-form" onSubmit={e => {e.preventDefault(); openDialog("login");}}>
                <label htmlFor="school-email">학교 구글 이메일 <span aria-hidden="true">*</span></label>
                <div className="email-field"><input id="school-email" type="email" name="email" required autoComplete="off" spellCheck={false} value={email} onChange={e => setEmail(e.target.value)} placeholder="학교 이메일 주소를 입력해 주세요"/><span>@</span></div>
                <p className="field-hint">학교에서 발급한 구글 계정만 사용할 수 있어요.</p>
                <button className="primary-button" type="submit"><span className="google-button-icon"><GoogleMark/></span>학교 계정으로 로그인<ArrowRight size={18}/></button>
              </form>
              <div className="secure-note"><ShieldCheck size={17}/><p>비밀번호는 <strong>구글 로그인 화면</strong>에서 입력해요.<br/>스쿨패스는 구글 비밀번호를 수집하지 않아요.</p></div>
            </>}
            <div className="card-bottom"><LockKeyhole size={13}/><span>{demo ? "이 화면은 로그인 이후의 UI 시연이에요" : "로그인 후 노트북 이용을 시작할 수 있어요"}</span></div>
          </div>
          <div className="device-info"><Laptop size={15}/><span>이 기기</span><b>학교 공용 노트북</b><span className="example-label">기기 정보 예시</span></div>
        </div>
      </section>

      <section className="usage-guide" aria-label="이용 안내"><div className="guide-title"><BookOpen size={19}/><b>사용하기 전,<br/>이것만 기억해요.</b></div><div className="guide-item"><span className="guide-number">1</span><div><h3>내 학교 계정으로 로그인</h3><p>친구의 계정을 대신 사용하지 않아요.</p></div></div><div className="guide-item"><span className="guide-number">2</span><div><h3>학습 목적으로 사용</h3><p>모두의 노트북을 소중하게 사용해요.</p></div></div><div className="guide-item"><span className="guide-number">3</span><div><h3>사용 후에는 로그아웃</h3><p>개인 정보를 남기지 않고 마무리해요.</p></div></div></section>
      <footer className="school-footer"><span>함께 쓰는 노트북, 함께 지키는 약속.</span><div><span className="preview-label">UI 미리보기</span><button onClick={() => openDialog("rules")}>이용 안내<ChevronRight size={13}/></button></div></footer>

      <dialog ref={dialogRef} className="school-dialog" aria-labelledby="dialog-title" onCancel={() => setDialog(null)} onClick={e => {if(e.target === e.currentTarget) closeDialog();}}>
        <button className="dialog-close" aria-label="닫기" onClick={closeDialog}><X size={20}/></button>
        <span className="lock-symbol">{dialog === "help" ? <CircleHelp size={24}/> : <ShieldCheck size={24}/>}</span>
        <h2 id="dialog-title">{dialog === "login" ? "로그인 화면을 미리 체험해요" : dialog === "help" ? "로그인이 어려운가요?" : "모두를 위한 노트북 이용 안내"}</h2>
        {dialog === "login" ? <><p>실제 구글 로그인은 아직 연결되지 않았어요. 연결 후에는 구글의 공식 로그인 화면에서 비밀번호를 입력해요.</p><div className="dialog-email">{email}</div><p>아래 버튼은 화면만 바꾸며, 계정 확인이나 윈도우 잠금 해제는 하지 않아요.</p><button className="primary-button" onClick={() => {setDemo(true); closeDialog();}}>로그인 후 화면 체험<ArrowRight size={18}/></button></> : dialog === "help" ? <><p>학교에서 발급한 구글 이메일 주소가 맞는지 확인해 주세요. 개인 구글 계정은 사용할 수 없어요.</p><p>이메일이나 비밀번호가 기억나지 않으면 담당 선생님께 문의해 주세요. 다른 학생에게 비밀번호를 알려주지 마세요.</p><button className="primary-button" onClick={closeDialog}>로그인 화면으로 돌아가기</button></> : <><ul className="rules-list"><li><Check size={17}/> 본인의 학교 계정만 사용해요.</li><li><Check size={17}/> 수업과 학습을 위해 사용해요.</li><li><Check size={17}/> 다른 사람의 파일을 열거나 지우지 않아요.</li><li><Check size={17}/> 사용 후에는 개인 계정에서 로그아웃해요.</li><li><Check size={17}/> 고장이나 문제가 있으면 선생님께 알려요.</li></ul><button className="primary-button" onClick={closeDialog}>안내 닫기</button></>}
      </dialog>
    </main>
  );
}
